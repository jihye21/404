package _4.domain;

import lombok.Data;

@Data
public class FileDTO {
	String orgFile;
	String storeFile;
}
