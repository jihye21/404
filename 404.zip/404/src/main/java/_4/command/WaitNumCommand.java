package _4.command;

import lombok.Data;

@Data
public class WaitNumCommand {
	String storeNum;
	String bookNum;
	Integer waitNum;
}
