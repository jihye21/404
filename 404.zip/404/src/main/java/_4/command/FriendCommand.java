package _4.command;

import java.util.Date;

import lombok.Data;

@Data
public class FriendCommand {
	String memNum;
	String friendNum;
	Date friendRegistDate;
}
