package _4.command;

import lombok.Data;

@Data
public class GroupCommand {
	String groupName;
	String memNum;
	String memName;
	
	String groupNum;
	String bookNum;
	
	Integer myDutchPrice;
}
